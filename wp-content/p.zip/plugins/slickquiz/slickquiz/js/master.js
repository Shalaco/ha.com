// Put all your page JS here

$(function () {
    $('#slickQuiz').slickQuiz();
});
