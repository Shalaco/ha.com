<div id="personal-upsell-content-classic-lens" class="upsell-modal">
	<div class="slidedeck-header">
	    <h1><?php _e( "Upgrade to Get The Classic Lens", $this->namespace ); ?></h1>
	</div>
	<div class="background">
		<div class="inner">
			<div class="copyblock">
                <div class="right">
    			    <h3><?php _e( "Use Classic for the Original SlideDeck Look", $this->namespace ); ?></h3>
    				<p><?php _e("The Classic lens is available in higher tiers of SlideDeck"); ?></p>
                </div>
				<div class="left">
                    <a href="#lens-upgrade" class="lens placeholder upgrade-modal" rel="lenses">
                        <span class="thumbnail"><img src="https://s3.amazonaws.com/slidedeck-pro/upsell_assets/images/lenses/classic/thumbnail.jpg" /></span>
                        <span class="title has-subtitle">Classic</span>
                        <span class="subtitle">Professional tier &amp; higher</span>
                    </a>
                </div>
			</div>
			<div class="cta">
				<a class="slidedeck-noisy-button" href="<?php echo slidedeck2_action( "/upgrades&referrer=Classic+Lens+Handslap" ); ?>" class="button slidedeck-noisy-button"><span>Upgrade</span></a>
				<a class="features-link" href="http://demo.slidedeck.com/wp-login.php?utm_campaign=sd2_personal&utm_medium=handslap_link&utm_source=handslap_lenses&utm_content=more_lenses_list<?php echo self::get_cohort_query_string('&'); ?>" target="_blank">or check out all the lenses in the live demo</a>
			</div>
		</div>
	</div>
</div>