<?php dynamic_sidebar( 'sidenav' ); ?>
<?php dynamic_sidebar( 'sidebar1' ); ?>