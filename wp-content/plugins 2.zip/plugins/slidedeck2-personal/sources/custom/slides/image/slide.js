(function($, window, undefined){
    $(function(){
        $('.content-source-custom .slidedeck .slide-source-custom .sd2-slide-text a').addClass('accent-color');
    });
})(jQuery, window, null);
