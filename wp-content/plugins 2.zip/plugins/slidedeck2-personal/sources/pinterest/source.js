(function($){
    window.PinterestSource = {
        elems: {},
        
        initialize: function(){
        	
        }
    };
    
    var ajaxOptions = [
        "options[pinterest_url]"
    ];
    for(var o in ajaxOptions){
        SlideDeckPreview.ajaxOptions.push(ajaxOptions[o]);
    }
    
    $(document).ready(function(){
        PinterestSource.initialize();
    });
})(jQuery);
