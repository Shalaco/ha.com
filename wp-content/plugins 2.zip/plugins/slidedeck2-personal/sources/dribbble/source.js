(function($){
    var ajaxOptions = [
        "options[dribbble_shots_or_likes]",
    ];
    for(var o in ajaxOptions){
        SlideDeckPreview.ajaxOptions.push(ajaxOptions[o]);
    }
})(jQuery);
