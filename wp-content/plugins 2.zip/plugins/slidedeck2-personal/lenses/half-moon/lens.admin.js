(function($){
	var ajaxOptions = [
        "options[navigation-style]",
        "options[navigation-area]"
	];
	for(i = 0; i < ajaxOptions.length; i++){
		SlideDeckPreview.ajaxOptions.push(ajaxOptions[i]);
	}
})(jQuery);