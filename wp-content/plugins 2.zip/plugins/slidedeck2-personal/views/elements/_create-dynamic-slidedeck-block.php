<div id="create-dynamic-slidedeck" class="create-slidedeck">
    <div class="slidedeck-inner">
	    <h4>Dynamic Source</h4>
	    <p>Create a slider that updates automatically with your favorite sources.</p>
	    <p><a href="<?php echo admin_url( "admin-ajax.php?action=slidedeck_source_modal&_wpnonce_source_modal=" ) . wp_create_nonce( 'slidedeck-source-modal' ); ?>" class="button create-button slidedeck-source-modal" onclick="return false;"><span><?php _e( "Create SlideDeck", $this->namespace ) ?></span></a></p>
	</div>
</div>