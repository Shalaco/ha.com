
    
    
    <footer class="bottom-bump give-me-some-space"  style="background-color:#ededed;">
      <div class="container" style="margin-top:20px;margin-bottom:20px">
      <div class="row">
       	<?php dynamic_sidebar( 'footer_sidebar' ); ?>
      </div>
      <div class="row-fluid flush ">
        <div class="span4 dashed">
           <ul class="menu" id="menu-footer-menu"><li class="menu-item menu-item-type-post_type menu-item-2636 parent" id="menu-item-2636"><a href="">About Hearing Loss</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2633" id="menu-item-2633"><a href="http://digwp.com/about/">How We Hear</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2634" id="menu-item-2634"><a href="http://digwp.com/advertising/">Hearing Loss</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2635" id="menu-item-2635"><a href="http://digwp.com/archives/">Tinnitus</a></li>
           </ul>
        </div>
        <div class="span4 dashed">
           <ul class="menu" id="menu-footer-menu"><li class="menu-item menu-item-type-post_type menu-item-2636 parent" id="menu-item-2636"><a href="">Hearing Loss &amp; You</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2633" id="menu-item-2633"><a href="http://digwp.com/about/">Effects of Hearing Loss</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2634" id="menu-item-2634"><a href="http://digwp.com/advertising/">Getting Friends &amp; Family to Accept Treatment</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2635" id="menu-item-2635"><a href="http://digwp.com/archives/">Avoiding Hearing Loss</a></li>
           </ul>
        </div>
        <div class="span4 dashed">
          <ul class="menu" id="menu-footer-menu"><li class="menu-item menu-item-type-post_type menu-item-2636 parent" id="menu-item-2636"><a href="">Hearing Aids 101</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2633" id="menu-item-2633"><a href="http://digwp.com/about/">How Hearing Aids Work</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2634" id="menu-item-2634"><a href="http://digwp.com/advertising/">Hearing Aid Buying Guide</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2635" id="menu-item-2635"><a href="http://digwp.com/archives/">Hearing Aids and Audio Equipment</a></li>
           </ul>
        </div>
      </div>
       <div class="row-fluid flush">
        <div class="span4 dashed">
           <ul class="menu" id="menu-footer-menu"><li class="menu-item menu-item-type-post_type menu-item-2636 parent" id="menu-item-2636"><a href="">About Hearing Loss</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2633" id="menu-item-2633"><a href="http://digwp.com/about/">How We Hear</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2634" id="menu-item-2634"><a href="http://digwp.com/advertising/">Hearing Loss</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2635" id="menu-item-2635"><a href="http://digwp.com/archives/">Tinnitus</a></li>
           </ul>
        </div>
        <div class="span4 dashed">
           <ul class="menu" id="menu-footer-menu"><li class="menu-item menu-item-type-post_type menu-item-2636 parent" id="menu-item-2636"><a href="">About Hearing Loss</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2633" id="menu-item-2633"><a href="http://digwp.com/about/">How We Hear</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2634" id="menu-item-2634"><a href="http://digwp.com/advertising/">Hearing Loss</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2635" id="menu-item-2635"><a href="http://digwp.com/archives/">Tinnitus</a></li>
           </ul>
        </div>
        <div class="span4 dashed">
           <ul class="menu" id="menu-footer-menu"><li class="menu-item menu-item-type-post_type menu-item-2636 parent" id="menu-item-2636"><a href="">About Hearing Loss</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2633" id="menu-item-2633"><a href="http://digwp.com/about/">How We Hear</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2634" id="menu-item-2634"><a href="http://digwp.com/advertising/">Hearing Loss</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-2635" id="menu-item-2635"><a href="http://digwp.com/archives/">Tinnitus</a></li>
           </ul>
           <?php wp_footer(); ?>
        </div>
      </div>
      </div><!-- /row-fluid-->
      <div class="span12 copyright container">
        <br/>
        <p >© Copyright 2013 Siemens. All rights reserved</p>
      </div>
    </div>
    </footer>
    
    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
<!--    <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/bootstrap-transition.js"></script>
    <script src="../assets/js/bootstrap-alert.js"></script>
    <script src="../assets/js/bootstrap-modal.js"></script>
    <script src="../assets/js/bootstrap-dropdown.js"></script>
    <script src="../assets/js/bootstrap-scrollspy.js"></script>
    <script src="../assets/js/bootstrap-tab.js"></script>
    <script src="../assets/js/bootstrap-tooltip.js"></script>
    <script src="../assets/js/bootstrap-popover.js"></script>
    <script src="../assets/js/bootstrap-button.js"></script>
    <script src="../assets/js/bootstrap-collapse.js"></script>
    <script src="../assets/js/bootstrap-carousel.js"></script>
    <script src="../assets/js/bootstrap-typeahead.js"></script>-->
    <!--share this-->
    <script type="text/javascript">var switchTo5x=true;</script>
    <script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
    <script type="text/javascript">stLight.options({publisher: "1982b8a2-7809-4d45-b050-0e7ed676b35b", doNotHash: true, doNotCopy: false, hashAddressBar: true});</script>
    
  </body>
</html>
