/**
 * SlideDeck Lens Admin Scripts
 * 
 * This script file will be loaded automatically in the SlideDeck edit view
 * of the WordPress control panel when this lens is chosen.
 * 
 * You must include all your JavaScript in the SlideDeckLensAdmin[LENS_SLUG]
 * function, or it will not be run when the Lens is chosen in real time by
 * the user in the editing view.
 */
