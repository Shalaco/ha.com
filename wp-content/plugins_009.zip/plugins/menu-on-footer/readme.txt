=== Plugin Name ===
Contributors: cavimaster
Tags: footer, menu, unrolled, category, pages , sitemap
Requires at least: 3.0
Tested up to: 3.3
Stable tag: 1.3

Create a simple configurable unrolled menu on your in a widget or in your wp_footer.

== Description ==

Create a simple configurable unrolled menu on your in a widget or in your wp_footer.

Possible configuration:

. Use like plugin or widget

. Show, unshow categories

. Depth of categories

. Categories order by

. Exclude categories

. Show, unshow pages

. Depth of pages

. Exclude pages

. Modify the css file directly on the settings -> Menu on Footer 

Use the widget mode arranges the problems centering

If you want to make the update of this plugin, make sure you have a backup of your modify CSS !!!

<a href="http://www.devsector.ch/cavimaster/2011/11/menu-on-footer/" target="_blank">Cavimaster Blog on Devsector.ch</a>

== Installation ==

   
   1. Download the .zip file
   2. Extract the contents and upload into your wp-content/plugins directory
   3. Activate the plugin in your WordPress Dashboard
   4. Configure it on settings -> Menu on Footer into the admin page 


== Frequently Asked Questions ==

= In plugin mode: Why menu-on-footer appear under the initial footer? =

Depend of your theme... it's easy, go on your "wp-content/themes/your_theme/footer.php" and deplace " wp_footer();" like you want


== Screenshots ==

1. In action
2. Admin configuration

== Changelog ==

= 1.3 =
* Creation of the widget object. You can choose specifictly to use like a plugin or like a widget.
= 1.2 =
* Fixbug on the CSS header calling
= 1.1 =
* Fixbug on the settings links
= 1.0 =
* This is the first version of the plugin.

